const { verifyToken } = require('../../lib/jwt');

const authRequired = async (req,res,next) =>{
    try{
        if(req.cookies.jwtToken) return next();
        else throw new Error('NOT_EXIST');
    }catch(err){
        throw next(err);
    }
};
const authToken = async(req,res,next) =>{
    try{
        const verified = verifyToken(req.cookies.jwtToken);
        req.id = verified.id;
        req.displayName = verified.displayName;
        return next();
    }catch(err){
        throw err;
    }
};
module.exports = { authRequired, authToken };