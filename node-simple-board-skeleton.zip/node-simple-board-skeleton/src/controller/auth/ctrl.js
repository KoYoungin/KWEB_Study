const { has } = require('lodash');
const { UserDAO } = require('../../DAO');
const{verifyPassword, generatePassword} = require('../../lib/authentication');

const signInForm = async (req, res, next) => {
    try{
        const { user } = req.session;
        if(user) return res.redirect('/');
        else return res.render('auth/sign-in.pug',{ user });
    } catch(err){
        return next(err);
    }
};

const signIn = async(req,res,next)=>{
    try{
        const {username,password} = req.body;
        if(!username || !password) throw new Error('BAD_REQUEST');  //bad발생할때 사용
        
        const user = await UserDAO.getByUsername(username);
        if(!user) throw new Error('UNAUTHORIZED');
        const isValid = await verifyPassword(password,user.password);
        if(!isValid) throw new Error('UNAUTHROIZED');

        req.session.user = {
            id: user.id,
            username,
            displayName: user.displayName,
            isActive: user.isActive,
            isStaff: user.isStaff
        };

        return res.redirect('/');

    }catch(err){
        return next(err);
    }
};

const signUpForm = async (req, res, next) => {
    try{
        const { user } = req.session;
        if(user) return res.redirect('/');
        else return res.render('auth/sign-up.pug',{ user });
    } catch(err){
        return next(err);
    }
};
const signUp = async(req,res,next)=>{
    try{
        const {username,password,displayName} = req.body;
        if(!username || !password||!displayName|| username.length > 16||displayName.length > 32 || password.length>151) 
            throw new Error('BAD_REQUEST');  //bad발생할때 사용

        const hashedPassword = await generatePassword(password);

        await UserDAO.create(username,hashedPassword,displayName);

        return res.redirect('/auth/sign_in');

    }catch(err){
        return next(err);
    }
};
const signOut = async(req,res,next)=>{
    try{
        req.session.destroy(err => {
            if(err) throw err;
            else res.redirect('/');
        })
    }catch(err){
        return next(err);
    }
};

module.exports = {
    signInForm, signUpForm,
    signIn, signOut, signUp,
}