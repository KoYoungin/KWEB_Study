const { ArticleDAO } = require('../../DAO');

const readArticle  = async (req,res,next) => {
    try{
        const articleId = parseInt(req.params.articleId,10);
        const{user} = req.session;

        const article = await ArticleDAO.getById(articleId);
        if(!article) throw new Error('NOT_EXIST');

        return res.render('articles/details.pug',{user,article});
    }catch(err){
        return next(err);
    }
};

const writeArticleForm = async(req,res,next)=>{
    try{
        const{user} = req.session;
        return res.render('articles/editor.pug',{user});
    }catch(err){
        return next(err);
    }
};

const writeArticle = async(req,res,next)=>{
    try{
        const {user} = req.session;
        const {title,content} =  req.body;

        const trimTitle = title.trim();
        const trimContent = content.trim();

        if(!trimTitle||trimTitle.length > 50||!trimContent||trimContent.length>65535)
            throw new Error('BAD_REQUEST');
        
        const newArticleID = await ArticleDAO.create(trimTitle,trimContent,user);

        return res.redirect(`/article/${newArticleID}`);

    }catch(err){
        return next(err);
    }
};

const editorArticleForm  = async (req,res,next) => {
    try{
        const articleId = parseInt(req.params.articleId,10);
        const{ user } = req.session;

        const userid = parseInt(user.id,10);
        const article = await ArticleDAO.getByIdAndAuthor(articleId,userid);
        if(!article) throw new Error('NOT_EXIST');

        return res.render('articles/editor.pug',{user,article});
    }catch(err){
        return next(err);
    }
};
const editorArticle  = async (req,res,next) => {
    try{
        const {user} = req.session;
        const {title,content} =  req.body;
        const articleId = parseInt(req.params.articleId,10);
        const userid = parseInt(user.id,10);

        const trimTitle = title.trim();
        const trimContent = content.trim();

        if(!trimTitle||trimTitle.length > 50||!trimContent||trimContent.length>65535)
            throw new Error('BAD_REQUEST');
        const article = await ArticleDAO.getByIdAndAuthor(articleId,userid);
        if(!article) throw new Error('NOT_EXIST');
        await ArticleDAO.update(articleId,trimTitle,trimContent);

        return res.redirect(`/article/${articleId}`);
    }catch(err){
        return next(err);
    }
};

const deleteArticle  = async (req,res,next) => {
    try{
        const {user} = req.session;
        const articleId = parseInt(req.params.articleId,10);
        const userid = parseInt(user.id,10);

        const article = await ArticleDAO.getByIdAndAuthor(articleId,userid);
        if(!article) throw new Error('NOT_EXIST');

        await ArticleDAO.remove(articleId);

        return res.redirect('/articles');
        
    }catch(err){
        return next(err);
    }
};

module.exports = {
    readArticle, writeArticleForm, 
    writeArticle, editorArticleForm, 
    editorArticle, deleteArticle,
};
