const { Router } = require('express');
const ctrl = require('./ctrl');
const { authRequired } = require('../auth/middleware');

const router = Router();

router.get('/:articleId(\\d+)', ctrl.readArticle);    //  \\d - article 안에 숫자만 matching ㄱㄴ

router.get('/compose', authRequired ,ctrl.writeArticleForm);
router.post('/compose', authRequired ,ctrl.writeArticle);

router.get('/edit/:articleId(\\d+)', authRequired ,ctrl.editorArticleForm);
router.post('/edit/:articleId(\\d+)', authRequired ,ctrl.editorArticle);

router.get('/delete/:articleId(\\d+)', authRequired ,ctrl.deleteArticle);

module.exports = router;